Police Report Management System

The Police Report Management System is designed to streamline the reporting and tracking of police reports through a web interface and a mobile application, with a backend supported by Python and PHP.

Prerequisites
Python 3.x
PHP 7.4 or higher
MySQL
Flutter

Usage
Web Application: Open your web browser and navigate to http://localhost/ or the configured domain.
Mobile Application: Install the app on your mobile device and run it.